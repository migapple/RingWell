//
//  Ring_WellApp.swift
//  Ring Well Watch App
//
//  Created by Michel Garlandat on 16/10/2026.
//

import SwiftUI

@main
struct Ring_Well_Watch_AppApp: App {
    var body: some Scene {
        WindowGroup {
            RingWellView()
        }
    }
}
