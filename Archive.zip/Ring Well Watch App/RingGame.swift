import SwiftUI
import WatchKit

// MARK: - Pièces

/// Une case d'une pièce, relative à son origine.
/// dr : décalage en anneaux (0 = bord intérieur de la pièce, 1 = vers l'extérieur)
/// ds : décalage en secteurs (0 = secteur du haut de l'écran)
struct PieceCell: Hashable {
    let dr: Int
    let ds: Int
}

struct PieceShape {
    let cells: [PieceCell]

    /// Arcs et formes radiales — volontairement pas de tétrominos.
    static let all: [PieceShape] = [
        PieceShape(cells: [PieceCell(dr: 0, ds: 0)]),                                              // point
        PieceShape(cells: [PieceCell(dr: 0, ds: 0), PieceCell(dr: 0, ds: 1)]),                      // arc 2
        PieceShape(cells: [PieceCell(dr: 0, ds: -1), PieceCell(dr: 0, ds: 0), PieceCell(dr: 0, ds: 1)]), // arc 3
        PieceShape(cells: [PieceCell(dr: 0, ds: 0), PieceCell(dr: 1, ds: 0)]),                      // rayon 2
        PieceShape(cells: [PieceCell(dr: 0, ds: 0), PieceCell(dr: 0, ds: 1), PieceCell(dr: 1, ds: 0)]), // coin
        PieceShape(cells: [PieceCell(dr: 0, ds: 0), PieceCell(dr: 0, ds: 1),
                           PieceCell(dr: 1, ds: 0), PieceCell(dr: 1, ds: 1)])                       // bloc
    ]
}

struct FallingPiece {
    var shape: PieceShape
    var ring: Int
    var color: Int
}

/// Position d'une case du plateau (anneau, secteur).
struct CellPos: Hashable {
    let r: Int
    let s: Int
}

// MARK: - Moteur de jeu

/// Puits circulaire : les pièces naissent au centre et tombent vers l'extérieur.
/// La Digital Crown fait tourner tout le plateau sous la pièce.
///
/// Deux façons d'effacer des cases :
///  • un anneau complet (toutes couleurs confondues) ;
///  • un groupe d'au moins `minGroup` cases de même couleur qui se touchent
///    (voisines sur le même anneau, ou dans le même secteur sur l'anneau voisin).
/// Après chaque effacement, les cases restantes tombent vers l'extérieur dans leur secteur,
/// ce qui peut déclencher des réactions en chaîne (multiplicateur de score).
@Observable
@MainActor
final class RingGame {
    static let rings = 12   // anneaux 2 fois moins épais (ex-6) → parties plus longues
    static let sectors = 12
    static let sectorAngle = 2 * Double.pi / Double(sectors)
    static let minGroup = 6

    /// 5 couleurs : groupes plus difficiles à former.
    static let palette: [Color] = [
        Color(red: 1.00, green: 0.78, blue: 0.20),  // or (couronne)
        Color(red: 0.95, green: 0.35, blue: 0.40),  // rouge
        Color(red: 0.35, green: 0.75, blue: 0.95),  // bleu
        Color(red: 0.45, green: 0.85, blue: 0.50),  // vert
        Color(red: 0.70, green: 0.50, blue: 0.95)   // violet
    ]

    var board: [[Int?]] = Array(repeating: Array(repeating: nil, count: sectors), count: rings)
    var piece: FallingPiece?
    var next: FallingPiece
    /// Rotation cumulée (non bornée, pour que l'animation ne fasse jamais un tour complet à l'envers).
    var rotation = 0
    var score = 0
    var ringsCleared = 0
    var groupsCleared = 0
    /// Cases sur le point d'être effacées (affichées en surbrillance).
    var flashing: Set<CellPos> = []
    /// Numéro de la réaction en chaîne en cours (affiché « ×2 », « ×3 »…).
    var chain = 0
    var isGameOver = false
    var isPaused = false
    var best: Int = UserDefaults.standard.integer(forKey: "crownDropBest")

    var level: Int { 1 + (ringsCleared + groupsCleared / 2) / 3 }
    /// Deux fois plus d'anneaux à traverser → pas de chute deux fois plus court,
    /// pour qu'une pièce mette le même temps à atteindre le bord.
    var interval: Double { max(0.09, 0.35 - Double(level - 1) * 0.03) }

    init() {
        next = RingGame.randomPiece()
        spawn()
    }

    static func randomPiece() -> FallingPiece {
        FallingPiece(shape: PieceShape.all.randomElement()!,
                     ring: 0,
                     color: Int.random(in: 0..<palette.count))
    }

    // MARK: Coordonnées

    private func wrap(_ s: Int) -> Int {
        let m = s % Self.sectors
        return m < 0 ? m + Self.sectors : m
    }

    /// Secteur du plateau situé sous le secteur d'écran `screenSector`.
    func boardSector(_ screenSector: Int, rotation rot: Int) -> Int {
        wrap(screenSector - rot)
    }

    func fits(_ p: FallingPiece, ring: Int, rotation rot: Int) -> Bool {
        for c in p.shape.cells {
            let r = ring + c.dr
            guard r >= 0, r < Self.rings else { return false }
            if board[r][boardSector(c.ds, rotation: rot)] != nil { return false }
        }
        return true
    }

    // MARK: Actions

    func tick() {
        guard !isGameOver, !isPaused, var p = piece else { return }
        if fits(p, ring: p.ring + 1, rotation: rotation) {
            p.ring += 1
            piece = p
        } else {
            lock()
        }
    }

    /// Rotation du plateau, cran par cran ; bloquée si la pièce entrerait en collision.
    func rotate(by delta: Int) {
        guard !isGameOver, !isPaused, delta != 0 else { return }
        let step = delta > 0 ? 1 : -1
        for _ in 0..<abs(delta) {
            let newRot = rotation + step
            if let p = piece, !fits(p, ring: p.ring, rotation: newRot) {
                WKInterfaceDevice.current().play(.directionUp)
                return
            }
            rotation = newRot
        }
    }

    /// Chute instantanée (tap).
    func hardDrop() {
        guard !isGameOver, !isPaused, var p = piece else { return }
        var distance = 0
        while fits(p, ring: p.ring + 1, rotation: rotation) {
            p.ring += 1
            distance += 1
        }
        piece = p
        score += distance   // 1 pt par anneau traversé
        lock()
    }

    func restart() {
        board = Array(repeating: Array(repeating: nil, count: Self.sectors), count: Self.rings)
        rotation = 0
        score = 0
        ringsCleared = 0
        groupsCleared = 0
        flashing = []
        chain = 0
        isGameOver = false
        isPaused = false
        next = Self.randomPiece()
        spawn()
    }

    /// Remet le record à zéro (depuis l'écran d'aide).
    func resetBest() {
        best = 0
        UserDefaults.standard.set(0, forKey: "crownDropBest")
    }

    // MARK: Pose et résolution

    private func lock() {
        guard let p = piece else { return }
        for c in p.shape.cells {
            board[p.ring + c.dr][boardSector(c.ds, rotation: rotation)] = p.color
        }
        piece = nil   // pas de pièce pendant la résolution : tick() et le tap sont ignorés
        WKInterfaceDevice.current().play(.click)
        Task { await resolveThenSpawn() }
    }

    /// Efface anneaux complets et groupes de couleur, fait tomber, et recommence
    /// tant qu'il y a quelque chose à effacer (réactions en chaîne).
    private func resolveThenSpawn() async {
        chain = 0
        while true {
            let fullRings = (0..<Self.rings).filter { r in board[r].allSatisfy { $0 != nil } }
            let groups = colorGroups()

            var toClear = Set<CellPos>()
            for r in fullRings {
                for s in 0..<Self.sectors { toClear.insert(CellPos(r: r, s: s)) }
            }
            for g in groups { toClear.formUnion(g) }
            if toClear.isEmpty { break }

            chain += 1

            // Score : anneaux + 10 pts par case de groupe, × niveau × chaîne
            let ringTable = [0, 100, 300, 600, 1000]
            let ringPts = ringTable[min(fullRings.count, 4)]
            let groupPts = groups.reduce(0) { $0 + $1.count * 10 }
            score += (ringPts + groupPts) * level * chain
            ringsCleared += fullRings.count
            groupsCleared += groups.count

            // Surbrillance, puis effacement
            flashing = toClear
            WKInterfaceDevice.current().play(chain > 1 ? .notification : .success)
            try? await Task.sleep(for: .milliseconds(260))
            for pos in toClear { board[pos.r][pos.s] = nil }
            flashing = []

            applyGravity()
            try? await Task.sleep(for: .milliseconds(140))
        }
        chain = 0
        spawn()
    }

    /// Groupes connexes d'au moins `minGroup` cases de même couleur.
    private func colorGroups() -> [Set<CellPos>] {
        var seen = Set<CellPos>()
        var result: [Set<CellPos>] = []

        for r in 0..<Self.rings {
            for s in 0..<Self.sectors {
                let start = CellPos(r: r, s: s)
                guard let color = board[r][s], !seen.contains(start) else { continue }

                var group = Set<CellPos>()
                var stack = [start]
                seen.insert(start)
                while let cur = stack.popLast() {
                    group.insert(cur)
                    let neighbors = [
                        CellPos(r: cur.r, s: wrap(cur.s - 1)),
                        CellPos(r: cur.r, s: wrap(cur.s + 1)),
                        CellPos(r: cur.r - 1, s: cur.s),
                        CellPos(r: cur.r + 1, s: cur.s)
                    ]
                    for n in neighbors where n.r >= 0 && n.r < Self.rings && !seen.contains(n) {
                        if board[n.r][n.s] == color {
                            seen.insert(n)
                            stack.append(n)
                        }
                    }
                }
                if group.count >= Self.minGroup { result.append(group) }
            }
        }
        return result
    }

    /// Dans chaque secteur, les cases tombent vers l'extérieur et comblent les trous.
    private func applyGravity() {
        for s in 0..<Self.sectors {
            var column: [Int] = []
            for r in stride(from: Self.rings - 1, through: 0, by: -1) {
                if let c = board[r][s] { column.append(c) }
            }
            for (i, r) in stride(from: Self.rings - 1, through: 0, by: -1).enumerated() {
                board[r][s] = i < column.count ? column[i] : nil
            }
        }
    }

    private func spawn() {
        var p = next
        p.ring = 0
        next = Self.randomPiece()
        if fits(p, ring: 0, rotation: rotation) {
            piece = p
        } else {
            piece = nil
            isGameOver = true
            WKInterfaceDevice.current().play(.failure)
            if score > best {
                best = score
                UserDefaults.standard.set(best, forKey: "crownDropBest")
            }
        }
    }
}
