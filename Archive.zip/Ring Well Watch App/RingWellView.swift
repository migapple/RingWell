import SwiftUI

// MARK: - Langue (FR / EN)

enum GameLang: String {
    case fr, en

    static var system: GameLang {
        Locale.current.language.languageCode?.identifier == "fr" ? .fr : .en
    }

    var flag: String { self == .fr ? "🇫🇷" : "🇬🇧" }
    var toggled: GameLang { self == .fr ? .en : .fr }

    var gameOver: String  { self == .fr ? "Partie terminée" : "Game over" }
    var best: String      { self == .fr ? "Record : " : "Best: " }
    var replay: String    { self == .fr ? "Touchez pour rejouer" : "Tap to play again" }
    var level: String     { self == .fr ? "Niv. " : "Lvl " }
    var hintCrown: String { self == .fr ? "Couronne : tourner" : "Crown: rotate" }
    var hintTap: String   { self == .fr ? "Toucher : lâcher" : "Tap: drop" }

    // Aide
    var helpTitle: String { self == .fr ? "Comment jouer" : "How to play" }
    var helpClose: String { self == .fr ? "Jouer" : "Play" }
    var resetButton: String  { self == .fr ? "Remettre le record à 0" : "Reset best score" }
    var resetConfirm: String { self == .fr ? "Effacer le record ?" : "Erase best score?" }
    var resetYes: String     { self == .fr ? "Effacer" : "Erase" }
    var resetNo: String      { self == .fr ? "Annuler" : "Cancel" }
    var resetDone: String    { self == .fr ? "Record remis à 0" : "Best score reset" }
    var helpItems: [(icon: String, text: String)] {
        let n = RingGame.minGroup
        if self == .fr {
            return [
                ("circle.dotted", "Les pièces apparaissent au centre et tombent vers le bord de l'écran."),
                ("digitalcrown.arrow.clockwise", "Tournez la Digital Crown pour faire pivoter tout l'anneau sous la pièce."),
                ("hand.tap", "Touchez l'écran pour lâcher la pièce d'un coup."),
                ("circle.circle", "Un anneau complet disparaît, quelles que soient les couleurs."),
                ("paintpalette", "\(n) cases ou plus de la même couleur qui se touchent disparaissent aussi."),
                ("arrow.down.circle", "Les cases restantes tombent vers l'extérieur : enchaînez les combos (×2, ×3…) !"),
                ("speedometer", "La vitesse augmente avec le niveau. La partie s'arrête quand le centre est bloqué.")
            ]
        } else {
            return [
                ("circle.dotted", "Pieces appear in the center and fall toward the edge of the screen."),
                ("digitalcrown.arrow.clockwise", "Turn the Digital Crown to rotate the whole ring under the piece."),
                ("hand.tap", "Tap the screen to drop the piece instantly."),
                ("circle.circle", "A complete ring disappears, whatever its colors."),
                ("paintpalette", "\(n) or more touching cells of the same color disappear too."),
                ("arrow.down.circle", "Remaining cells fall outward: chain combos (×2, ×3…)!"),
                ("speedometer", "Speed increases with each level. The game ends when the center is blocked.")
            ]
        }
    }
}

// MARK: - Écran d'aide

struct HelpView: View {
    let lang: GameLang
    let best: Int
    let onReset: () -> Void
    @Environment(\.dismiss) private var dismiss
    @State private var confirmReset = false
    @State private var didReset = false

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 10) {
                Text(lang.helpTitle)
                    .font(.headline)
                    .foregroundStyle(RingGame.palette[0])
                ForEach(Array(lang.helpItems.enumerated()), id: \.offset) { _, item in
                    HStack(alignment: .top, spacing: 8) {
                        Image(systemName: item.icon)
                            .frame(width: 20)
                            .foregroundStyle(RingGame.palette[0])
                        Text(item.text)
                            .font(.footnote)
                            .fixedSize(horizontal: false, vertical: true)
                    }
                }
                Button(lang.helpClose) { dismiss() }
                    .tint(RingGame.palette[0])
                    .padding(.top, 4)

                // Remise à zéro du record, avec confirmation
                Divider().padding(.vertical, 2)
                Text(lang.best + "\(didReset ? 0 : best)")
                    .font(.footnote)
                    .foregroundStyle(.secondary)
                if didReset {
                    Label(lang.resetDone, systemImage: "checkmark")
                        .font(.footnote)
                        .foregroundStyle(.green)
                } else {
                    Button(role: .destructive) {
                        confirmReset = true
                    } label: {
                        Label(lang.resetButton, systemImage: "arrow.counterclockwise")
                            .font(.footnote)
                    }
                    .disabled(best == 0)
                }
            }
            .padding(.horizontal, 4)
        }
        .confirmationDialog(lang.resetConfirm, isPresented: $confirmReset, titleVisibility: .visible) {
            Button(lang.resetYes, role: .destructive) {
                onReset()
                didReset = true
            }
            Button(lang.resetNo, role: .cancel) {}
        }
    }
}

// MARK: - Géométrie des cases (secteurs d'anneau)

enum RingGeo {
    static func cellPath(ring: Int, sector: Int, in size: CGSize) -> Path {
        let center = CGPoint(x: size.width / 2, y: size.height / 2)
        let maxR = min(size.width, size.height) / 2 * 0.995
        let inner = maxR * 0.11                       // trou central réduit = plus de place pour le jeu
        let thickness = (maxR - inner) / CGFloat(RingGame.rings)
        let r0 = inner + CGFloat(ring) * thickness + 0.8
        let r1 = inner + CGFloat(ring + 1) * thickness - 0.8

        let w = RingGame.sectorAngle
        let gap = 0.022
        let a0 = -Double.pi / 2 + (Double(sector) - 0.5) * w + gap
        let a1 = a0 + w - 2 * gap

        var p = Path()
        p.addArc(center: center, radius: r1, startAngle: .radians(a0), endAngle: .radians(a1), clockwise: false)
        p.addArc(center: center, radius: r0, startAngle: .radians(a1), endAngle: .radians(a0), clockwise: true)
        p.closeSubpath()
        return p
    }
}

// MARK: - Calques

/// Plateau, dessiné en coordonnées plateau ; la rotation est appliquée par rotationEffect (animée).
private struct BoardLayer: View {
    let board: [[Int?]]
    let flashing: Set<CellPos>

    var body: some View {
        Canvas { ctx, size in
            for r in 0..<RingGame.rings {
                for s in 0..<RingGame.sectors {
                    let path = RingGeo.cellPath(ring: r, sector: s, in: size)
                    if flashing.contains(CellPos(r: r, s: s)) {
                        ctx.fill(path, with: .color(.white))   // case sur le point de disparaître
                    } else if let c = board[r][s] {
                        ctx.fill(path, with: .color(RingGame.palette[c]))
                    } else {
                        ctx.fill(path, with: .color(.white.opacity(0.07)))
                    }
                }
            }
        }
    }
}

/// Pièce en chute, dessinée en coordonnées écran : toujours en haut, le plateau tourne dessous.
private struct PieceLayer: View {
    let piece: FallingPiece?

    var body: some View {
        Canvas { ctx, size in
            // Repère du couloir de chute
            for r in 0..<RingGame.rings {
                ctx.fill(RingGeo.cellPath(ring: r, sector: 0, in: size),
                         with: .color(.white.opacity(0.05)))
            }
            guard let p = piece else { return }
            for c in p.shape.cells {
                let path = RingGeo.cellPath(ring: p.ring + c.dr, sector: c.ds, in: size)
                ctx.fill(path, with: .color(RingGame.palette[p.color]))
                ctx.stroke(path, with: .color(.white.opacity(0.9)), lineWidth: 1)
            }
        }
        .allowsHitTesting(false)
    }
}

// MARK: - Vue principale

struct RingWellView: View {
    @State private var game = RingGame()
    @State private var crown = 0.0
    @State private var lastStep = 0
    @State private var showHint = true
    @State private var showHelp = false
    @AppStorage("crownDropLang") private var langRaw = ""
    @Environment(\.scenePhase) private var scenePhase

    private var lang: GameLang { GameLang(rawValue: langRaw) ?? .system }

    var body: some View {
        // Le drapeau est un calque frère AU-DESSUS du jeu (et non un enfant du jeu) :
        // ainsi le tap du jeu (lâcher la pièce) ne peut plus intercepter le tap du drapeau.
        ZStack(alignment: .topLeading) {
            gameArea
                .onTapGesture {
                    showHint = false
                    if game.isGameOver { game.restart() } else { game.hardDrop() }
                }
            HStack(alignment: .top, spacing: 0) {   // drapeau et aide côte à côte
                flagButton
                helpButton
            }
        }
        .sheet(isPresented: $showHelp) {
            HelpView(lang: lang, best: game.best, onReset: { game.resetBest() })
        }
        .onChange(of: showHelp) { _, _ in updatePause() }
        .ignoresSafeArea()                 // le jeu occupe tout l'écran
        .focusable()
        .digitalCrownRotation($crown,
                              from: -100_000, through: 100_000, by: 1,
                              sensitivity: .low,
                              isContinuous: false,
                              isHapticFeedbackEnabled: true)
        .onChange(of: crown) { _, value in
            let step = Int(value.rounded())
            let delta = step - lastStep
            if delta != 0 {
                game.rotate(by: delta)
                lastStep = step
                showHint = false
            }
        }
        .onChange(of: scenePhase) { _, _ in updatePause() }
        .task {
            while !Task.isCancelled {
                try? await Task.sleep(for: .seconds(game.interval))
                game.tick()
            }
        }
    }

    // MARK: Zone de jeu

    private var gameArea: some View {
        GeometryReader { geo in
            let side = min(geo.size.width, geo.size.height)
            ZStack {
                BoardLayer(board: game.board, flashing: game.flashing)
                    .rotationEffect(.radians(Double(game.rotation) * RingGame.sectorAngle))
                    .animation(.easeOut(duration: 0.12), value: game.rotation)

                PieceLayer(piece: game.piece)

                // Réaction en chaîne : « ×2 », « ×3 »… au centre
                if game.chain > 1 {
                    Text("×\(game.chain)")
                        .font(.system(size: 22, weight: .heavy, design: .rounded))
                        .foregroundStyle(RingGame.palette[0])
                        .shadow(color: .black, radius: 2)
                        .transition(.scale.combined(with: .opacity))
                        .allowsHitTesting(false)
                }

                if game.isGameOver {
                    gameOverOverlay
                } else if showHint {
                    hintOverlay
                }
            }
            .frame(width: side, height: side)
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            // Coins du bas : niveau et score
            .overlay(alignment: .bottomLeading) {
                if !game.isGameOver { cornerLabel(lang.level + "\(game.level)") }
            }
            .overlay(alignment: .bottomTrailing) {
                if !game.isGameOver { cornerLabel("\(game.score)") }
            }
        }
        .contentShape(Rectangle())
    }

    /// Le jeu est en pause quand le poignet est baissé ou que l'aide est ouverte.
    private func updatePause() {
        game.isPaused = (scenePhase != .active) || showHelp
    }

    // MARK: Éléments d'interface

    private var helpButton: some View {
        Button {
            showHint = false
            showHelp = true
        } label: {
            Image(systemName: "questionmark")      // sans cercle
                .font(.system(size: 17, weight: .bold))
                .foregroundStyle(RingGame.palette[0])
                .frame(width: 20, height: 32)       // étroit : collé au drapeau, hors des anneaux
                .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
        .padding(.top, 8)                          // aligné sur le drapeau
    }

    private var flagButton: some View {
        Button {
            langRaw = lang.toggled.rawValue
        } label: {
            Text(lang.flag)
                .font(.system(size: 20))
                .frame(width: 28, height: 32)
                .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
        .padding(.leading, 10)                     // décalé des coins arrondis de l'écran
        .padding(.top, 8)
    }

    private func cornerLabel(_ text: String) -> some View {
        Text(text)
            .font(.system(size: 13, weight: .semibold, design: .rounded))
            .monospacedDigit()
            .padding(.horizontal, 6)
            .padding(.vertical, 2)
            .background(.black.opacity(0.6), in: Capsule())
            .padding(8)
    }

    private var hintOverlay: some View {
        VStack(spacing: 2) {
            Text(lang.hintCrown)
            Text(lang.hintTap)
        }
        .font(.system(size: 11, weight: .medium, design: .rounded))
        .padding(6)
        .background(.black.opacity(0.7), in: RoundedRectangle(cornerRadius: 8))
        .offset(y: 30)
        .allowsHitTesting(false)
    }

    private var gameOverOverlay: some View {
        VStack(spacing: 4) {
            Text(lang.gameOver)
                .font(.headline)
            Text("\(game.score)")
                .font(.system(size: 30, weight: .bold, design: .rounded))
                .monospacedDigit()
            Text(lang.best + "\(game.best)")
                .font(.footnote)
                .foregroundStyle(.secondary)
            Text(lang.replay)
                .font(.caption2)
                .foregroundStyle(RingGame.palette[0])
        }
        .padding(10)
        .background(.black.opacity(0.75), in: RoundedRectangle(cornerRadius: 14))
    }
}

#Preview {
    RingWellView()
}
